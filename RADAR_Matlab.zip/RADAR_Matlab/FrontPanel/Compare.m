%
%This DOPPLER RADAR TRAINER FRONT END SYSTEM was written by Nilesh Pardhe as a part of his personel use:
%This source code can be use for next level of development but copying will
%not be allowd.Please send details of your work and usefullness
%of this work in your scope @:- info.embone@gmail.com.
%this development inspired from G. L. Charvat, ``A Low-Power Radar Imaging System," Ph.D. dissertation,
%Dept. of Electrical and Computer Engineering, Michigan State University, East Lansing, MI, 2007.
%
%This code supplied under no warranty conditions.

function varargout = Compare(varargin)
% COMPARE MATLAB code for Compare.fig
%      COMPARE, by itself, creates a new COMPARE or raises the existing
%      singleton*.
%
%      H = COMPARE returns the handle to a new COMPARE or the handle to
%      the existing singleton*.
%
%      COMPARE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in COMPARE.M with the given input arguments.
%
%      COMPARE('Property','Value',...) creates a new COMPARE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Compare_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Compare_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Compare

% Last Modified by GUIDE v2.5 08-Mar-2017 07:33:50

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Compare_OpeningFcn, ...
                   'gui_OutputFcn',  @Compare_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Compare is made visible.
function Compare_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Compare (see VARARGIN)

% Choose default command line output for Compare
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Compare wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Compare_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in HomeBtn.
function HomeBtn_Callback(hObject, eventdata, handles)
% hObject    handle to HomeBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
display Goodbye
StartUpScreen;
close(handles.figure1)


% --- Executes on button press in SelectFile.
function SelectFile_Callback(hObject, eventdata, handles)
% hObject    handle to SelectFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global computeFile;
 [filename, pathname] = uigetfile('*.wav', 'Select a MATLAB code file');
if isequal(filename,0)
   disp('User selected Cancel')
   set(handles.ComputeBtn,'Enable','off');
else
   disp(['User selected ', fullfile(pathname, filename)])
   set(handles.SelctFileString,'String',fullfile(pathname, filename));
   computeFile = 0;
   set(handles.ComputeBtn,'Enable','on');
end


function Compute(hObject,handles)
global computeFile
if computeFile == 1
  NBITS = 16;
  FS = handles.Fs
  Y = getaudiodata(hObject);
else     
    S = get(handles.SelctFileString, 'String');
    if isempty(S)
      disp('no value');
    else
       % do computation here
       disp('value is present');
       [Y,FS,NBITS] = wavread(S);
%        figure
        %constants
    end
end
  
  c = 3E8; %(m/s) speed of light

 %radar parameters
 Tp = 0.250; %(s) pulse time
 N = Tp*FS; %# of samples per pulse
 fc = 2590E6; %(Hz) Center frequency (connected VCO Vtune to +5 for example)
 %fc = 2495E6; %(Hz) Center frequency within ISM band (VCO Vtune to +3.2V)
 
 %the input appears to be inverted
 s = -1*Y(:,2);
 figure;
 plot(s);
%         xlabel(handles.axes1,'time (sec)');
%        set(h1,'xtick',[]);
%         ylim(handles.axesRadar01Data,[-0.5,0.5]);
%         ylabel(h,'Mag (v)');
%         legend(h,'Echo Mag');
title(S);
%  axes(handles.axesRadar01WF);
%  plot(handles.axesRadar01WF,Y);
 
 clear Y;
 
 %creat doppler vs. time plot data set here
 for ii = 1:round(size(s,1)/N)-1
    sif(ii,:) = s(1+(ii-1)*N:ii*N);
 end
%subtract the average DC term here
 sif = sif - mean(s);
 %xlswrite('sif.xlsx',sif);
 zpad = 8*N/2;
 
 %doppler vs. time plot:
 v = dbv(ifft(sif,zpad,2));
 %xlswrite('dvb.xlsx',v);
 v = v(:,1:size(v,2)/2);
 %A = [12.7, 5.02, -98, 63.9, 0, -.2, 56];
 %xlswrite('v1234.xlsx',v);
 
 mmax = max(max(v));
 %calculate velocity
 delta_f = linspace(0, FS/2, size(v,2)); %(Hz)
 lambda=c/fc;
 velocity = delta_f*lambda/2;
 %calculate time
 time = linspace(1,Tp*size(v,1),size(v,1)); %(sec)
 %plot

 %subplot(1,2,1


% axes(handles.axesRadar01WD);
figure;
imagesc(velocity,time,v-mmax,[-35, 0]); 
title(S);

 %imshow(h);

 colorbar;
 xlim([0 40]); %limit velocity axis
 xlabel('Velocity (m/sec)');
 ylabel('time (sec)');
 clear all;


% --- Executes on button press in ComputeBtn.
function ComputeBtn_Callback(hObject, eventdata, handles)
% hObject    handle to ComputeBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 global computeFile
 computeFile = 0;
 Compute(hObject,handles);



function SelctFileString_Callback(hObject, eventdata, handles)
% hObject    handle to SelctFileString (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SelctFileString as text
%        str2double(get(hObject,'String')) returns contents of SelctFileString as a double


% --- Executes during object creation, after setting all properties.
function SelctFileString_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SelctFileString (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
