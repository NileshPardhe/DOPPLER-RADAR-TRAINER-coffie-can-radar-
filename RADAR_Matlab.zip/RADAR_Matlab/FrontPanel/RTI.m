%
%This DOPPLER RADAR TRAINER FRONT END SYSTEM(RTI) was written by Nilesh Pardhe as a part of his personel use:
%This source code can be use for next level of development but copying will
%not be allowd.Please share details of your work and usefullness
%of this work in your scope @:- info.embone@gmail.com.
%this development inspired from G. L. Charvat, ``A Low-Power Radar Imaging System," Ph.D. dissertation,
%Dept. of Electrical and Computer Engineering, Michigan State University, East Lansing, MI, 2007.
%
%This code supplied under no warranty conditions.


function varargout = RTI(varargin)
% RTI MATLAB code for RTI.fig
%      RTI, by itself, creates a new RTI or raises the existing
%      singleton*.
%
%      H = RTI returns the handle to a new RTI or the handle to
%      the existing singleton*.
%
%      RTI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RTI.M with the given input arguments.
%
%      RTI('Property','Value',...) creates a new RTI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RTI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RTI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RTI

% Last Modified by GUIDE v2.5 21-Feb-2017 16:22:47

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RTI_OpeningFcn, ...
                   'gui_OutputFcn',  @RTI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before RTI is made visible.
function RTI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to RTI (see VARARGIN)

% Choose default command line output for RTI
handles.output = hObject;

movegui(gcf,'center')


handles.Fs = 44100;
handles.samples =0;
 % create the recorder
handles.recorder = audiorecorder(handles.Fs, 16, 2);
nDevices = audiodevinfo(1)%to read audio  input devices
if(nDevices>0)
    handles.recorder = audiorecorder(handles.Fs, 16, 2);
 % assign a timer function to the recorder
    set(handles.recorder,'TimerPeriod',1,'TimerFcn',{@audioTimer,hObject});
     % save the handles structure 
    guidata(hObject, handles);
else 
%     mode  = struct('')
   errorMsg = errordlg('Audio Device Not Found','Device Not Found','modal')
    % save the handles structure 
   guidata(hObject, handles);
   close(handles.figure1)
end

stop(handles.recorder);
global computeFile;
computeFile = 0;
%computeFile =0
set(handles.Stop,'Enable','off');
set(handles.Save,'Enable','off');
set(handles.Compute,'Enable','off');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes RTI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = RTI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Compute.
function Compute_Callback(hObject, eventdata, handles)
% hObject    handle to Compute (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global computeFile
    computeFile = 0;
    Compute(hObject,handles);
    
function Compute(hObject,handles)
%read the raw data .wave file here
global computeFile
if computeFile == 1
  NBITS = 16;
  FS = handles.Fs
  Y = getaudiodata(hObject);
else     
    S = get(handles.FileName, 'String');
    if isempty(S)
      disp('no value');
    else
       % do computation here
       disp('value is present');
       [Y,FS,NBITS] = wavread(S);
       %figure
        %constants
    end
end




%constants
c = 3E8; %(m/s) speed of light

%radar parameters
Tp = 20E-3; %(s) pulse time
N = Tp*FS; %# of samples per pulse
fstart = 2248E6; %2260E6(Hz) LFM start frequency for example
fstop = 2260E6; %2590E6(Hz) LFM stop frequency for example
%fstart = 2402E6; %(Hz) LFM start frequency for ISM band
%fstop = 2495E6; %(Hz) LFM stop frequency for ISM band
BW = fstop-fstart; %(Hz) transmti bandwidth
f = linspace(fstart, fstop, N/2); %instantaneous transmit frequency

%range resolution
rr = c/(2*BW);
max_range = rr*N/2;

%the input appears to be inverted
trig = -1*Y(:,1);
s = -1*Y(:,2);
% for iFilt =1:(size(s))
%     if abs(s(iFilt)) > 0.05
%         s(iFilt)=s(iFilt)*10;
%     end
% end

% figure
% plot(Y)
plot(handles.axesRTIData,s);
ylim(handles.axesRTIData,[-0.5,0.5]);
set(handles.axesRTIData,'xtick',[]);
%         xlabel(handles.axesRTIData,'time (sec)');
        ylabel(handles.axesRTIData,'Mag (v)');
        legend(handles.axesRTIData,'Echo Mag');
clear Y;

%parse the data here by triggering off rising edge of sync pulse
count = 0;
thresh = 0;
start = (trig > thresh);
for ii = 100:(size(start,1)-N)
    if start(ii) == 1 & mean(start(ii-11:ii-1)) == 0
        %start2(ii) = 1;
        count = count + 1;
        sif(count,:) = s(ii:ii+N-1);
        time(count) = ii*1/FS;
    end
end
%check to see if triggering works
% figure;
% plot(trig);
% hold on;
% figure;
% plot(sif);
% hold off;
% grid on;
ave = mean(sif,1);
for ii = 1:size(sif,1);
    sif(ii,:) = sif(ii,:) - ave;
end

zpad = 8*N/2;

%RTI plot
% figure(10);
v = dbv(ifft(sif,zpad,2));
S = v(:,1:size(v,2)/2);
m = max(max(v));
axes(handles.axesRTIOD)
imagesc(linspace(0,max_range,zpad),time,S-m,[-50, 0]);
colorbar;
ylabel('time (s)');
xlabel('range (m)');
title('RTI without clutter rejection');

%2 pulse cancelor RTI plot
% figure(20);
sif2 = sif(2:size(sif,1),:)-sif(1:size(sif,1)-1,:);
v = ifft(sif2,zpad,2);
S=v;
R = linspace(0,max_range,zpad);
for ii = 1:size(S,1)
    %S(ii,:) = S(ii,:).*R.^(3/2); %Optional: magnitude scale to range
end
S = dbv(S(:,1:size(v,2)/2));
m = max(max(S));
axes(handles.axesRTIRD)
imagesc(R,time,S-m,[-50, -10]);
colorbar;
ylabel('time (s)');
xlabel('range (m)');
title('RTI with 2-pulse cancelor clutter rejection');


% % %2 pulse mag only cancelor
% figure(30);
% clear v;
% for ii = 1:size(sif,1)-1
%     v1 = abs(ifft(sif(ii,:),zpad));
%     v2 = abs(ifft(sif(ii+1,:),zpad));
%     v(ii,:) = v2-v1;
% end
% S=v;
% R = linspace(0,max_range,zpad);
% for ii = 1:size(S,1)
%     S(ii,:) = S(ii,:).*R.^(3/2); %Optional: magnitude scale to range
% end
% S = dbv(S(:,1:size(v,2)/2));
% m = max(max(S));
% imagesc(R,time,S-m,[-20, 0]);
% colorbar;
% ylabel('time (s)');
% xlabel('range (m)');
% title('RTI with 2-pulse mag only cancelor clutter rejection');


% --- Executes on button press in SelectFile.
function SelectFile_Callback(hObject, eventdata, handles)
% hObject    handle to SelectFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 global computeFile;
 [filename, pathname] = uigetfile('*.wav', 'Select a MATLAB code file');
if isequal(filename,0)
   disp('User selected Cancel')
   set(handles.Compute,'Enable','off');
else
   disp(['User selected ', fullfile(pathname, filename)])
   set(handles.FileName,'String',fullfile(pathname, filename));   
   computeFile = 0;
   set(handles.Compute,'Enable','on');
end



function FileName_Callback(hObject, eventdata, handles)
% hObject    handle to FileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FileName as text
%        str2double(get(hObject,'String')) returns contents of FileName as a double


% --- Executes during object creation, after setting all properties.
function FileName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Close.
function Close_Callback(hObject, eventdata, handles)
% hObject    handle to Close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
display Goodbye_RTIClosed
stop(handles.recorder);
StartUpScreen;
close(handles.figure1)


% --- Executes on button press in Run.
function Run_Callback(hObject, eventdata, handles)
% hObject    handle to Run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global computeFile 
computeFile = 1;
set(handles.Stop,'Enable','on');
set(handles.Run,'Enable','off');
set(handles.Save,'Enable','off');
set(handles.Compute,'Enable','off');
set(handles.SelectFile,'Enable','off');
record(handles.recorder);

% --- Executes on button press in Stop.
function Stop_Callback(hObject, eventdata, handles)
% hObject    handle to Stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Stop,'Enable','off');
set(handles.Run,'Enable','on');
set(handles.Save,'Enable','on');
set(handles.Compute,'Enable','on');
set(handles.SelectFile,'Enable','on');

stop(handles.recorder);



% --- Executes on button press in Save.
function Save_Callback(hObject, eventdata, handles)
% hObject    handle to Save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load handel.mat
 [filename, pathname] = uiputfile('*.wav', 'Create New File','untitled.wav');
if isequal(filename,0)
   disp('User selected Cancel')
else
   disp(['User selected ', fullfile(pathname, filename)])
   %set(handles.FileName,'String',fullfile(pathname, filename));
   samples  = getaudiodata(handles.recorder);
   audiowrite(fullfile(pathname, filename),samples,handles.Fs);
   clear samples handles.Fs 
   end
   

function audioTimer(hObject,varargin)
    hFigure = varargin{2};
    handles1 = guidata(hFigure);
    Compute(hObject,handles1);  


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
delete(hObject);
