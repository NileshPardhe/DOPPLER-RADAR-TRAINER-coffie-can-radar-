
%
%This DOPPLER RADAR TRAINER FRONT END SYSTEM was written by Nilesh Pardhe as a part of his personel use:
%This source code can be use for next level of development but copying will
%not be allowd.Please share details of your work and usefullness
%of this work in your scope @:- info.embone@gmail.com.
%this development inspired from G. L. Charvat, ``A Low-Power Radar Imaging System," Ph.D. dissertation,
%Dept. of Electrical and Computer Engineering, Michigan State University, East Lansing, MI, 2007.
%
%This code supplied under no warranty conditions.


function varargout = Radar01(varargin)
% RADAR01 MATLAB code for Radar01.fig
%      RADAR01, by itself, creates a new RADAR01 or raises the existing
%      singleton*.
%
%      H = RADAR01 returns the handle to a new RADAR01 or the handle to
%      the existing singleton*.
%
%      RADAR01('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RADAR01.M with the given input arguments.
%
%      RADAR01('Property','Value',...) creates a new RADAR01 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Radar01_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Radar01_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Radar01

% Last Modified by GUIDE v2.5 22-Feb-2017 12:31:59

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Radar01_OpeningFcn, ...
                   'gui_OutputFcn',  @Radar01_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Radar01 is made visible.
function Radar01_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Radar01 (see VARARGIN)

% Choose default command line output for Radar01
handles.output = hObject;
movegui(gcf,'center')
set(gcf, 'units','normalized','outerposition',[0 0 1 1]);
handles.Fs = 44100;
handles.samples =0;
 % create the recorder
%  ax = axes('Parent',handles.axesRadar01WF)
%  hAxes = axes(handles.axesRadar01WF)
% handles.hhAxes=ax;

handles.recorder = audiorecorder(handles.Fs, 16, 2);
nDevices = audiodevinfo(1)%to read audio  input devices
if(nDevices>0)
    handles.recorder = audiorecorder(handles.Fs, 16, 2);
 % assign a timer function to the recorder
    set(handles.recorder,'TimerPeriod',1,'TimerFcn',{@audioTimer,hObject});
     % save the handles structure 
    guidata(hObject, handles);
else 
%     mode  = struct('')
   errorMsg = errordlg('Audio Device Not Found','Device Not Found','modal')
    % save the handles structure 
   guidata(hObject, handles);
   close(handles.figure1)
end

guidata(hObject, handles);
 % assign a timer function to the recorder
stop(handles.recorder);
global computeFile;
computeFile = 0;
%computeFile =0
set(handles.StopBtn,'Enable','off');
set(handles.SaveBtn,'Enable','off');
set(handles.ComputeBtn,'Enable','off');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Radar01 wait for user response (see UIRESUME)
% uiwait(handles.figure1);
function audioTimer(hObject,varargin)
     hFigure = varargin{2};
     handles = guidata(hFigure);
     Compute(hObject,handles);  


% --- Outputs from this function are returned to the command line.
function varargout = Radar01_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in RunBtn.
function RunBtn_Callback(hObject, eventdata, handles)
% hObject    handle to RunBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global computeFile 
computeFile = 1;
set(handles.StopBtn,'Enable','on');
set(handles.RunBtn,'Enable','off');
set(handles.SaveBtn,'Enable','off');
set(handles.ComputeBtn,'Enable','off');
set(handles.OpenBtn,'Enable','off');
record(handles.recorder);


% --- Executes on button press in StopBtn.
function StopBtn_Callback(hObject, eventdata, handles)
% hObject    handle to StopBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.StopBtn,'Enable','off');
set(handles.RunBtn,'Enable','on');
set(handles.SaveBtn,'Enable','on');
set(handles.ComputeBtn,'Enable','on');
set(handles.OpenBtn,'Enable','on');
stop(handles.recorder);

function Compute(hObject,handles)
global computeFile
if computeFile == 1
  NBITS = 16;
  FS = handles.Fs
  Y = getaudiodata(hObject);
else     
    S = get(handles.SelctFileString, 'String');
    if isempty(S)
      disp('no value');
    else
       % do computation here
       disp('value is present');
       [Y,FS,NBITS] = wavread(S);
%        figure
        %constants
    end
end
  
  c = 3E8; %(m/s) speed of light

 %radar parameters
 Tp = 0.250; %(s) pulse time
 N = Tp*FS; %# of samples per pulse
 fc = 2590E6; %(Hz) Center frequency (connected VCO Vtune to +5 for example)
 %fc = 2495E6; %(Hz) Center frequency within ISM band (VCO Vtune to +3.2V)
 
 %the input appears to be inverted
 s = -1*Y(:,2);
 plot(handles.axesRadar01Data,s);
%         xlabel(handles.axes1,'time (sec)');
        set(handles.axesRadar01Data,'xtick',[]);
%         ylim(handles.axesRadar01Data,[-0.5,0.5]);
        ylabel(handles.axesRadar01Data,'Mag (v)');
        legend(handles.axesRadar01Data,'Echo Mag');
        title(handles.axesRadar01Data,'A scope');
%  axes(handles.axesRadar01WF);
%  plot(handles.axesRadar01WF,Y);
 
 clear Y;
 
 %creat doppler vs. time plot data set here
 for ii = 1:round(size(s,1)/N)-1
    sif(ii,:) = s(1+(ii-1)*N:ii*N);
 end
%subtract the average DC term here
 sif = sif - mean(s);
 %xlswrite('sif.xlsx',sif);
 zpad = 8*N/2;
 
 %doppler vs. time plot:
 v = dbv(ifft(sif,zpad,2));
 %xlswrite('dvb.xlsx',v);
 v = v(:,1:size(v,2)/2);
 %A = [12.7, 5.02, -98, 63.9, 0, -.2, 56];
 %xlswrite('v1234.xlsx',v);
 
 mmax = max(max(v));
 %calculate velocity
 delta_f = linspace(0, FS/2, size(v,2)); %(Hz)
 lambda=c/fc;
 velocity = delta_f*lambda/2;
 %calculate time
 time = linspace(1,Tp*size(v,1),size(v,1)); %(sec)
 %plot

 %subplot(1,2,1


axes(handles.axesRadar01WD);
imagesc(velocity,time,v-mmax,[-35, 0]); 
title(handles.axesRadar01WD,'B scope');

 %imshow(h);

 colorbar;
 xlim([0 40]); %limit velocity axis
 xlabel('Velocity (m/sec)');
 ylabel('time (sec)');
 

% --- Executes on button press in SaveBtn.
function SaveBtn_Callback(hObject, eventdata, handles)
% hObject    handle to SaveBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load handel.mat
 [filename, pathname] = uiputfile('*.wav', 'Create New File','untitled.wav');
if isequal(filename,0)
   disp('User selected Cancel')
else
   disp(['User selected ', fullfile(pathname, filename)])
   %set(handles.FileName,'String',fullfile(pathname, filename));
   samples  = getaudiodata(handles.recorder);
   audiowrite(filename,samples,handles.Fs);
   clear samples handles.Fs   
end


% --- Executes on button press in OpenBtn.
function OpenBtn_Callback(hObject, eventdata, handles)
% hObject    handle to OpenBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global computeFile;
 [filename, pathname] = uigetfile('*.wav', 'Select a MATLAB code file');
if isequal(filename,0)
   disp('User selected Cancel')
   set(handles.ComputeBtn,'Enable','off');
else
   disp(['User selected ', fullfile(pathname, filename)])
   set(handles.SelctFileString,'String',fullfile(pathname, filename));
   computeFile = 0;
   set(handles.ComputeBtn,'Enable','on');
end



function SelctFileString_Callback(hObject, eventdata, handles)
% hObject    handle to SelctFileString (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SelctFileString as text
%        str2double(get(hObject,'String')) returns contents of SelctFileString as a double


% --- Executes during object creation, after setting all properties.
function SelctFileString_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SelctFileString (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ComputeBtn.
function ComputeBtn_Callback(hObject, eventdata, handles)
% hObject    handle to ComputeBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 global computeFile
 computeFile = 0;
 Compute(hObject,handles);


% --- Executes on button press in HomeBtn.
function HomeBtn_Callback(hObject, eventdata, handles)
% hObject    handle to HomeBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
display Goodbye
stop(handles.recorder);
StartUpScreen;
close(handles.figure1)


% --------------------------------------------------------------------
function uipushtool1_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to uipushtool1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% imgData = getframe(handles.axesRadar01Data)
f = getframe(handles.axesRadar01WD);
imgWD = frame2im(f)
imwrite(imgWD,'image.jpg')
