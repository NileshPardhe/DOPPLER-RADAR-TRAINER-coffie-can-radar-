%
%This DOPPLER RADAR TRAINER FRONT END SYSTEM was written by Nilesh Pardhe as a part of his personel use:
%This source code can be use for next level of development but copying will
%not be allowd.Please share details of your work and usefullness
%of this work in your scope @:- info.embone@gmail.com.
%this development inspired from G. L. Charvat, ``A Low-Power Radar Imaging System," Ph.D. dissertation,
%Dept. of Electrical and Computer Engineering, Michigan State University, East Lansing, MI, 2007.
%
%This code supplied under no warranty conditions.

function varargout = Radar01(varargin)
% MAIN MATLAB code for main.fig
%      MAIN, by itself, creates a new MAIN or raises the existing
%      singleton*.
%
%      H = MAIN returns the handle to a new MAIN or the handle to
%      the existing singleton*.
%
%      MAIN('RCALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN.M with the given input arguments.
%
%      MAIN('Property','Value',...) creates a new MAIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help main

% Last Modified by GUIDE v2.5 21-Feb-2017 16:44:38

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Radar01_OpeningFcn, ...
                   'gui_OutputFcn',  @Radar01_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before main is made visible.
function Radar01_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main (see VARARGIN)

% Choose default command line output for main

handles.output = hObject;
% Enlarge figure to full screen, but not truly maximized.
movegui(gcf,'center')
% set(gcf, 'units','normalized','outerposition',[0 0 1 1]);


handles.Fs = 44100;
handles.samples =0;
 % create the recorder
%  ax = axes('Parent',handles.axesRadar01WF)
%  hAxes = axes(handles.axesRadar01WF)
% handles.hhAxes=ax;
handles.recorder = audiorecorder(handles.Fs, 16, 2);

guidata(hObject, handles);
 % assign a timer function to the recorder
set(handles.recorder,'TimerPeriod',5,'TimerFcn',{@audioTimer,hObject});
stop(handles.recorder);
global computeFile;
computeFile = 0;
%computeFile =0
set(handles.Stop,'Enable','off');
set(handles.Save,'Enable','off');
set(handles.Compute,'Enable','off');

% set(gcf, 'units','normalized','outerposition',[0 0 1 1]);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Radar01_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Compute.
function Compute_Callback(hObject, eventdata, handles)
    global computeFile
    computeFile = 0;
    Compute(hObject,handles);
    
    

% --- Executes on button press in FileSelect.
function FileSelect_Callback(hObject, eventdata, handles)
global computeFile;
 [filename, pathname] = uigetfile('*.wav', 'Select a MATLAB code file');
if isequal(filename,0)
   disp('User selected Cancel')
   set(handles.Compute,'Enable','off');
else
   disp(['User selected ', fullfile(pathname, filename)])
   set(handles.FileName,'String',fullfile(pathname, filename));
   computeFile = 0;
   set(handles.Compute,'Enable','on');
end
% hObject    handle to FileSelect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function FileName_Callback(hObject, eventdata, handles)
% hObject    handle to FileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FileName as text
%        str2double(get(hObject,'String')) returns contents of FileName as a double


% --- Executes during object creation, after setting all properties.
function FileName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in AppClose.
function AppClose_Callback(hObject, eventdata, handles)
display Goodbye
stop(handles.recorder);
StartUpScreen;
close(handles.figure1)

% hObject    handle to AppClose (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in Run.
function Run_Callback(hObject, eventdata, handles)
% hObject    handle to Run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global computeFile 
computeFile = 1;
set(handles.Stop,'Enable','on');
set(handles.Run,'Enable','off');
set(handles.Save,'Enable','off');
set(handles.Compute,'Enable','off');
set(handles.FileSelect,'Enable','off');
record(handles.recorder);


% --- Executes on button press in Stop.
function Stop_Callback(hObject, eventdata, handles)
% hObject    handle to Stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Stop,'Enable','off');
set(handles.Run,'Enable','on');
set(handles.Save,'Enable','on');
set(handles.Compute,'Enable','on');
set(handles.FileSelect,'Enable','on');
stop(handles.recorder);

function Compute(hObject,handles)
global computeFile
if computeFile == 1
  NBITS = 16;
  FS = handles.Fs
  Y = getaudiodata(hObject);
else     
    S = get(handles.FileName, 'String');
    if isempty(S)
      disp('no value');
    else
       % do computation here
       disp('value is present');
       [Y,FS,NBITS] = wavread(S);
%        figure
        %constants
    end
end
  
  c = 3E8; %(m/s) speed of light

 %radar parameters
 Tp = 0.250; %(s) pulse time
 N = Tp*FS; %# of samples per pulse
 fc = 2590E6; %(Hz) Center frequency (connected VCO Vtune to +5 for example)
 %fc = 2495E6; %(Hz) Center frequency within ISM band (VCO Vtune to +3.2V)
 
 %the input appears to be inverted
 s = -1*Y(:,2);
 plot(handles.axesRadar01Data,s);
%  axes(handles.axesRadar01WF);
%  plot(handles.axesRadar01WF,Y);
 
 clear Y;
 
 %creat doppler vs. time plot data set here
 for ii = 1:round(size(s,1)/N)-1
    sif(ii,:) = s(1+(ii-1)*N:ii*N);
 end
%subtract the average DC term here
 sif = sif - mean(s);
 %xlswrite('sif.xlsx',sif);
 zpad = 8*N/2;
 
 %doppler vs. time plot:
 v = dbv(ifft(sif,zpad,2));
 %xlswrite('dvb.xlsx',v);
 v = v(:,1:size(v,2)/2);
 %A = [12.7, 5.02, -98, 63.9, 0, -.2, 56];
 %xlswrite('v1234.xlsx',v);
 
 mmax = max(max(v));
 %calculate velocity
 delta_f = linspace(0, FS/2, size(v,2)); %(Hz)
 lambda=c/fc;
 velocity = delta_f*lambda/2;
 %calculate time
 time = linspace(1,Tp*size(v,1),size(v,1)); %(sec)
 %plot

 %subplot(1,2,1


axes(handles.axesRadar01WF);
imagesc(velocity,time,v-mmax,[-35, 0]); 

 %imshow(h);

 colorbar;
 xlim([0 40]); %limit velocity axis
 xlabel('Velocity (m/sec)');
 ylabel('time (sec)');  
 
 
 %set(handles.axesRadar01Data,'CurrentAxes',im);


function audioTimer(hObject,varargin)
     hFigure = varargin{2};
     handles = guidata(hFigure);
     Compute(hObject,handles);   
    


% --- Executes on button press in Save.
function Save_Callback(hObject, eventdata, handles)
% hObject    handle to Save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load handel.mat
 [filename, pathname] = uiputfile('*.wav', 'Create New File','untitled.wav');
if isequal(filename,0)
   disp('User selected Cancel')
else
   disp(['User selected ', fullfile(pathname, filename)])
   %set(handles.FileName,'String',fullfile(pathname, filename));
   samples  = getaudiodata(handles.recorder);
   audiowrite(filename,samples,handles.Fs);
   clear samples handles.Fs   
end


% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: delete(hObject) closes the figure
delete(hObject);
