%
%This DOPPLER RADAR TRAINER FRONT END SYSTEM(Recorder) was written by Nilesh Pardhe as a part of his personel use:
%This source code can be use for next level of development but copying will
%not be allowd.Please share details of your work and usefullness
%of this work in your scope @:- info.embone@gmail.com.
%this development inspired from G. L. Charvat, ``A Low-Power Radar Imaging System," Ph.D. dissertation,
%Dept. of Electrical and Computer Engineering, Michigan State University, East Lansing, MI, 2007.
%
%This code supplied under no warranty conditions.
function varargout = Recorder(varargin)
% RECORDER MATLAB code for Recorder.fig
%      RECORDER, by itself, creates a new RECORDER or raises the existing
%      singleton*.
%
%      H = RECORDER returns the handle to a new RECORDER or the handle to
%      the existing singleton*.
%
%      RECORDER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RECORDER.M with the given input arguments.
%
%      RECORDER('Property','Value',...) creates a new RECORDER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Recorder_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Recorder_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Recorder

% Last Modified by GUIDE v2.5 12-Nov-2016 16:42:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Recorder_OpeningFcn, ...
                   'gui_OutputFcn',  @Recorder_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Recorder is made visible.
function Recorder_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Recorder (see VARARGIN)

% Choose default command line output for Recorder
handles.output = hObject;

% Update handles structure
%guidata(hObject, handles);
set(handles.Stop,'Enable','off');
set(handles.Save,'Enable','off');
handles.Fs = 44100;
handles.samples =0;
 % create the recorder
handles.recorder = audiorecorder(handles.Fs, 16, 2);
nDevices = audiodevinfo(1)%to read audio  input devices
if(nDevices>0)
    handles.recorder = audiorecorder(handles.Fs, 16, 2);
 % assign a timer function to the recorder
    set(handles.recorder,'TimerPeriod',1,'TimerFcn',{@audioTimer,hObject});
     % save the handles structure 
    guidata(hObject, handles);
else 
%     mode  = struct('')
   errorMsg = errordlg('Audio Device Not Found','Device Not Found','modal')
    % save the handles structure 
   guidata(hObject, handles);
   close(handles.figure1)
end



% UIWAIT makes Recorder wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Recorder_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Record.
function Record_Callback(hObject, eventdata, handles)
% hObject    handle to Record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Stop,'Enable','on');
%recObj = audiorecorder(44100, 16, 2);
%get(recObj)
record(handles.recorder);



% --- Executes on button press in Stop.
function Stop_Callback(hObject, eventdata, handles)
% hObject    handle to Stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Save,'Enable','on');
stop(handles.recorder);





% --- Executes on button press in Save.
function Save_Callback(hObject, eventdata, handles)
% hObject    handle to Save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load handel.mat
 [filename, pathname] = uiputfile('*.wav', 'Create New File','untitled.wav');
if isequal(filename,0)
   disp('User selected Cancel')
else
   disp(['User selected ', fullfile(pathname, filename)])
   %set(handles.FileName,'String',fullfile(pathname, filename));
   samples  = getaudiodata(handles.recorder);
   audiowrite(fullfile(pathname, filename),samples,handles.Fs);
   clear samples handles.Fs   
end

function audioTimer(hObject,varargin)
        % get the sample data
        samples  = getaudiodata(hObject);
        hFigure = varargin{2};

       % get the handles structure so we can access the plots/axes
       handles = guidata(hFigure);
         
        % skip if not enough data
        %if length(handles.samples)<lastSampleIdx+1+handles.Fs
        %*   return;
       % end
        
        
        % extract the samples that we have not performed an FFT on
       % X = handles.samples(handles.lastSampleIdx+1:handles.lastSampleIdx+handles.Fs);
        
        % compute the FFT
        %Y = fft(X,N);
        
        % plot the data
        %plot(samples(:,2));
        %t = linspace(0,size(samples,2),size(samples,2));
        %samples(:,1);
       
        plot(handles.axes1,samples);
        xlabel(handles.axes1,'time (sec)');
        ylabel(handles.axes1,'Mag (v)');
        legend(handles.axes1,'Echo Mag','Sync');
        
%          ylim(handles.axes1,[-0.8,1]);
       
        %set(handles.axes1,'XData',t,'YData',X)
        %t = linspace(0,1-1/Fs,Fs) + handles.atTimSecs;
        %set(hPlot1,'XData',t,'YData',X);
        
        %f = 0:Fs/N:(Fs/N)*(N-1);
        %set(hPlot2,'XData',f,'YData',abs(Y));
         
        % increment the last sample index
        %handles.lastSampleIdx = lastSampleIdx + Fs;
        
        % increment the time in seconds "counter"
        %handles.atTimSecs     = handles.atTimSecs + 1; 
    

% --- Executes on button press in Close.
function Close_Callback(hObject, eventdata, handles)
% hObject    handle to Close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
display RecorderClosed
stop(handles.recorder);
StartUpScreen;
close(handles.figure1)
