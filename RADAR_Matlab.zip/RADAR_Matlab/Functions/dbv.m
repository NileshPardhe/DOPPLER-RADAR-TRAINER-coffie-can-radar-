function out = dbv(in)
%DB conversion
%   Detailed explanation goes here
   out = 20 * log10(abs(in));
end

