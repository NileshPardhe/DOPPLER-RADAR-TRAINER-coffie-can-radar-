function lic = actxlicense(progid)

if strcmpi(progid, 'CWUIControlsLib.CWBoolean.1')
lic = 'mbpegflkijoiimifhmjccidjihmjlbdnhbmkjlncbahpafnbcilinmeigb';
return;
end
